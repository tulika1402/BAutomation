#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pdfplumber
import pandas as pd


pdf_file_path = "C://Users/91947/Downloads/5608119616.pdf"

# Open the PDF file
with pdfplumber.open(pdf_file_path) as pdf:
    # Extract text from the first page
    first_page_text = pdf.pages[0].extract_text()

    # Extract tables from the first page
    tables = pdf.pages[0].extract_tables()

    if tables:
        # Assuming your PDF contains structured tables, extract the first table
        first_table = tables[0]

      


# In[4]:


first_table 


# In[11]:


# Convert the extracted table into a DataFrame
df = pd.DataFrame(first_table[1:], columns=first_table[0])

      # Print the DataFrame
print(df)
  


# In[ ]:




