#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pdfplumber
import pandas as pd
import re

pdf_file_path = "C://Users/91947/Downloads/Inv_SL-S01_6081_job010HB40YOJJ5W7495263B79.dat.pdf"

# Open the PDF file
with pdfplumber.open(pdf_file_path) as pdf:
    # Extract text from the first page
    text = pdf.pages[0].extract_text()

   


# In[2]:


text


# In[3]:


list_data = text.split('\n')
print(list_data)


# In[4]:


#date

import re

pattern = r'\d{2}/\d{2}/\d{2}'
date_list = []

# Iterate over each element in list_data
for item in list_data:
    # Find all matches of the pattern in the current item
    dates = re.findall(pattern, item)
    # Extend the date_list with the found dates
    date_list.extend(dates)

print("date",date_list)


# In[14]:


vat_num = []
for index, item in enumerate(list_data):
    if "VAT" in item:
        start_index = index
        end_index = start_index + 4
        merged_string = ' '.join(list_data[start_index:end_index])
        VAT = re.search(r'\b\d{6,}\b', merged_string)
        if VAT:
          vat_num.append(VAT.group())
          print("VAT Number:", VAT.group())
        else:
            print("VAT Number not found")
        break
vat_num


# In[15]:


#name
pattern = r'[A-Z]+\s+[A-Z]+\s+[A-Z]+\s&+\s+[A-Z]+\s[A-Z]+. '

name_list1= []

# Iterate over each element in list_data
for item in list_data:
    # Find all matches of the pattern in the current item
    name = re.findall(pattern, item)
    # Extend the date_list with the found dates
    name_list1.extend(name)

print(name_list1)


# In[27]:


#TOTALAMOUNT
amt = []
for index, item in enumerate(list_data):
    if "Total BHD Value" in item:
        print(item)
        amt.append(item[-7:])
            

amt


# In[37]:


vat = []
for index, item in enumerate(list_data):
    if "Vat Amount" in item:
        print(item)
        vat.append(item[-6:])
            

vat


# In[38]:


inv = []
for index, item in enumerate(list_data):
    if "Doc" in item:
        print(item)
        inv.append(item[-4:])
            

inv


# In[61]:


#description  'Purchase Department cost allocation', 'for the month of Aug 23'
pattern = r'[A-Z][a-z]+\s+[A-Z][a-z]+\s+[a-z]+\s+[a-z]+'
des=[]


# In[62]:


import re

# Your pattern
pattern = r'[A-Z][a-z]+\s+[A-Z][a-z]+\s+[a-z]+\s+[a-z]+'

# Iterate over each element in list_data
for item in list_data:
    # Find all matches of the pattern in the current item
    n = re.findall(pattern, item)
    # If matches are found
    if n:
        # Add the first match to the date_list
        des.append(n[0])
        # Break out of the loop
        break

print(des)


# In[72]:


#description 'for the month of Aug 23'

pattern = r'[a-z]+\s+[a-z]+\s+[a-z]+\s+[a-z]+\s+[A-Z][a-z]+\s+[0-9]+'
des1=[]


# In[73]:


# Iterate over each element in list_data
for item in list_data:
    # Find all matches of the pattern in the current item
    nn = re.findall(pattern, item)
    # Extend the date_list with the found dates
    des1.extend(nn)




print(des1)


# In[76]:


import pandas as pd


# In[88]:


result_string = ' '.join(des + des1)
print(result_string)


# In[83]:


type(result_string)


# In[89]:


l=[]
l.append(result_string)


# In[90]:


l


# In[91]:


# Assuming you have the previously defined lists: date_list, name_list, etc.

data = {
    "Date": date_list,
    "Name": name_list1,
    "Invoice No": inv,
    "Description": l,
    "Total Amount": amt,
    "VAT amount": vat
}

# Get the maximum length of any list in the dictionary
max_length = max(len(value) for value in data.values())

# Fill empty lists with an appropriate value (e.g., None) to ensure equal length
for key, value in data.items():
    data[key] = value + [None] * (max_length - len(value))

# Create DataFrame using dictionary comprehension
df = pd.DataFrame(data)

# Display DataFrame
print(df)


# In[ ]:




